<?php
header('Content-type:application/json;charset=utf-8');
include "conn.php";

/*$_POST['noplat'] = "B 210 KK";
$_POST['username'] = "admincs";
$_POST['namabengkel'] = "Mazda Jakarta Barat";
$_POST['jenisservis'] = "Fast Track";
$_POST['sesiservis'] = "Pagi (08.00 - 11.00)";
$_POST['tanggalservis'] = "2020-05-25";
$_POST['catatan'] = "Tune up, Spooring and Balancing";*/

	
    $noplat = $_POST['noplat'];
    $username = $_POST['username'];
    $namabengkel = $_POST['namabengkel'];
    $jenisservis = $_POST['jenisservis'];
    $sesiservis = $_POST['sesiservis'];
    $tanggalservis = $_POST['tanggalservis'];
    $catatan = $_POST['catatan'];
    $status = $_POST['status'];
	
	$q=mysqli_query($mysqli,"INSERT INTO servicereservation(noplat,username,namabengkel,jenisservis,sesiservis,tanggalservis,catatan,status) VALUES ('$noplat','$username','$namabengkel','$jenisservis','$sesiservis','$tanggalservis','$catatan','$status')");
	$response = array();
	
	if($q){
		$response["success"] =1;
		$response["message"] = "Data berhasil ditambah";
		echo json_encode($response);
	}
	else{
		$response["success"] =0;
		$response["message"] = "Data gagal ditambah";
		echo json_encode($response);
	}
?>