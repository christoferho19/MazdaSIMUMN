<?php
   header('content-type:application/json;charset=utf-8');
   include "conn.php";

   /*$_POST['namabengkel'] = "Mazda Jakarta Timur";
   $_POST['passwordbengkel'] = "mazda01";*/

   $namabengkel = $_POST['namabengkel'];
   $passwordbengkel = $_POST['passwordbengkel'];
   $q=mysqli_query($mysqli,"select * from workshopdata where namabengkel='$namabengkel' AND passwordbengkel ='$passwordbengkel'");
   $response=array();
   
   if (mysqli_num_rows($q)>0)
   {
	  $response["data"]=array();
	  while($r=mysqli_fetch_array($q))
	  {
	  $user=array();
	  $user["namabengkel"]=$r["namabengkel"];
	  //$user["password"]=$r["password"];
      //$user["email"]=$r["email"];
      //$user["status"]=$r["status"];
	  array_push($response["data"],$user);
	  }
      $response["success"]=1;
	  $response["message"]="data berhasil diambil";
      echo json_encode($response);
   }
   else
   { 
	  $response["success"]=-1;
	  $response["message"]="data kosong";
	  echo json_encode($response);

	}
	  
?>	