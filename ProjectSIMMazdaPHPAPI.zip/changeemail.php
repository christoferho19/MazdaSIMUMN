<?php
    header('Content-type:application/json;charset=utf-8');
    include "conn.php";

    //$_POST['username'] = "admincs";
    //$_POST['password'] = "admincs";
    //$_POST['email'] = "admincs@mazda.mfy.com";

    if(isset($_POST['username']) && isset($_POST['password']) && isset($_POST['email'])){
        $username = $_POST['username'];
        $password = $_POST['password'];
        $email = $_POST['email'];

        $q=mysqli_query($mysqli,"UPDATE userlogin SET email='$email' WHERE username='$username' AND password='$password'");
        $response = array();

        if($q){
            $response["success"] = 1;
            $response["message"] = "Data berhasil diupdate";
            echo json_encode($response);
        }
        else{
            $response["success"] = 0;
            $response["message"] = "Data gagal diupdate";
            echo json_encode($response);
        }
    }
    else{
        $response["success"] = -1;
        $response["message"] = "Data kosong";
        echo json_encode($response);
    }