<?php
$databaseHost = 'localhost';
$databaseName = 'id13797374_simmazda';
$databaseUsername = 'id13797374_ckhmfy';
$databasePassword = '$CKHmfyadmin19';

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName) or die ("Koneksi Gagal"); 
mysqli_select_db($mysqli,$databaseName) or die ("Database belum siap!");

?>