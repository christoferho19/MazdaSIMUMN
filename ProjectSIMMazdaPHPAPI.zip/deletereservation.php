<?php
    header('Content-type:application/json;charset=utf-8');
    include "conn.php";

    /*$_POST['noplat'] = "B 20 KM";
    $_POST['tanggalservis'] = "2020-05-25";*/
    
    $noplat = $_POST['noplat'];
    $tanggalservis = $_POST['tanggalservis'];

        $q=mysqli_query($mysqli,"DELETE FROM servicereservation WHERE noplat='$noplat' AND tanggalservis='$tanggalservis'");
        $response = array();

        if($q){
            $response["success"] = 1;
            $response["message"] = "Data berhasil dihapus";
            echo json_encode($response);
        }
        else{
            $response["success"] = 0;
            $response["message"] = "Data gagal dihapus";
            echo json_encode($response);
        }