<?php
    header('Content-type:application/json;charset=utf-8');
    include "conn.php";

    //$_POST['username'] = "admincs";
    //$_POST['alamat'] = "Jl. Veteran Utara 141";
    //$_POST['notelp'] = "085242798888";

    if(isset($_POST['username']) && isset($_POST['alamat']) && isset($_POST['notelp'])){
        $username = $_POST['username'];
        $alamat = $_POST['alamat'];
        $notelp = $_POST['notelp'];

        $q=mysqli_query($mysqli,"UPDATE cstdata SET alamat='$alamat', notelp='$notelp' WHERE username='$username'");
        $response = array();

        if($q){
            $response["success"] = 1;
            $response["message"] = "Data berhasil diupdate";
            echo json_encode($response);
        }
        else{
            $response["success"] = 0;
            $response["message"] = "Data gagal diupdate";
            echo json_encode($response);
        }
    }
    else{
        $response["success"] = -1;
        $response["message"] = "Data kosong";
        echo json_encode($response);
    }