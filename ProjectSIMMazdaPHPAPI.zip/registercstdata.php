<?php
header('Content-type:application/json;charset=utf-8');
include "conn.php";

/*$_POST['username'] = "ckh";
$_POST['firstname'] = "Christofer";
$_POST['lastname'] = "Horas";
$_POST['alamat'] = "Ruko Pascal Timur no.20";
$_POST['notelp'] = "081599218888";*/

	
    $username = $_POST['username'];
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $alamat = $_POST['alamat'];
    $notelp = $_POST['notelp'];
	
	$q=mysqli_query($mysqli,"INSERT INTO cstdata(username,firstname,lastname,alamat,notelp) VALUES ('$username','$firstname','$lastname','$alamat','$notelp')");
	$response = array();
	
	if($q){
		$response["success"] =1;
		$response["message"] = "Data berhasil ditambah";
		echo json_encode($response);
	}
	else{
		$response["success"] =0;
		$response["message"] = "Data gagal ditambah";
		echo json_encode($response);
	}
?>