<?php
    header('Content-type:application/json;charset=utf-8');
    include "conn.php";

    //$_POST['noplat'] = "B 20 KM";
    
    $noplat = $_POST['noplat'];

        $q=mysqli_query($mysqli,"DELETE FROM cardata WHERE noplat='$noplat'");
        $response = array();

        if($q){
            $response["success"] = 1;
            $response["message"] = "Data berhasil dihapus";
            echo json_encode($response);
        }
        else{
            $response["success"] = 0;
            $response["message"] = "Data gagal dihapus";
            echo json_encode($response);
        }