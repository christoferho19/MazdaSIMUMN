<?php
    header('Content-type:application/json;charset=utf-8');
    include "conn.php";

    /*$_POST['status'] = "on progress";
    $_POST['idreservasi'] = "10";*/

    if(isset($_POST['status']) && isset($_POST['idreservasi'])){
        $status = $_POST['status'];
        $idreservasi = $_POST['idreservasi'];

        $q=mysqli_query($mysqli,"UPDATE servicereservation SET status='$status' WHERE idreservasi='$idreservasi'");
        $response = array();

        if($q){
            $response["success"] = 1;
            $response["message"] = "Data berhasil diupdate";
            echo json_encode($response);
        }
        else{
            $response["success"] = 0;
            $response["message"] = "Data gagal diupdate";
            echo json_encode($response);
        }
    }
    else{
        $response["success"] = -1;
        $response["message"] = "Data kosong";
        echo json_encode($response);
    }