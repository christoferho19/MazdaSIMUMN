<?php
    header('Content-type:application/json;charset=utf-8');
    include "conn.php";

    //$_POST['username'] = "admincs";
    //$_POST['password'] = "admin";

    if(isset($_POST['username']) && isset($_POST['password'])){
        $username = $_POST['username'];
        $password = $_POST['password'];

        $q=mysqli_query($mysqli,"UPDATE userlogin SET password='$password' WHERE username='$username'");
        $response = array();

        if($q){
            $response["success"] = 1;
            $response["message"] = "Data berhasil diupdate";
            echo json_encode($response);
        }
        else{
            $response["success"] = 0;
            $response["message"] = "Data gagal diupdate";
            echo json_encode($response);
        }
    }
    else{
        $response["success"] = -1;
        $response["message"] = "Data kosong";
        echo json_encode($response);
    }