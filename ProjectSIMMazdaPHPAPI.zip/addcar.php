<?php
header('Content-type:application/json;charset=utf-8');
include "conn.php";

/*$_POST['noplat'] = "B 210 KK";
$_POST['username'] = "admincs";
$_POST['carmodel'] = "Mazda 6 Sedan";
$_POST['yearmodel'] = "2017";
$_POST['color'] = "Jet Black Mica";
$_POST['norangka'] = "PSA2KASLW9";
$_POST['nomesin'] = "ISAO021";*/

	
    $noplat = $_POST['noplat'];
    $username = $_POST['username'];
    $carmodel = $_POST['carmodel'];
    $yearmodel = $_POST['yearmodel'];
    $color = $_POST['color'];
    $norangka = $_POST['norangka'];
    $nomesin = $_POST['nomesin'];
	
	$q=mysqli_query($mysqli,"INSERT INTO cardata(noplat,username,carmodel,yearmodel,color,norangka,nomesin) VALUES ('$noplat','$username','$carmodel','$yearmodel','$color','$norangka','$nomesin')");
	$response = array();
	
	if($q){
		$response["success"] =1;
		$response["message"] = "Data berhasil ditambah";
		echo json_encode($response);
	}
	else{
		$response["success"] =0;
		$response["message"] = "Data gagal ditambah";
		echo json_encode($response);
	}
?>